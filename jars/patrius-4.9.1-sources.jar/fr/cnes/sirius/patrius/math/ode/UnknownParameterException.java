/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 *
 * Copyright 2011-2022 CNES
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * HISTORY
 * VERSION:4.9:FA:FA-3128:10/05/2022:[PATRIUS] Historique des modifications et Copyrights 
 * VERSION:4.3:DM:DM-2097:15/05/2019: Mise en conformite du code avec le nouveau standard de codage DYNVOL
 * END-HISTORY
 */
package fr.cnes.sirius.patrius.math.ode;

import fr.cnes.sirius.patrius.math.exception.MathIllegalArgumentException;
import fr.cnes.sirius.patrius.utils.exception.PatriusMessages;

/**
 * Exception to be thrown when a parameter is unknown.
 * 
 * @since 3.1
 * @version $Id: UnknownParameterException.java 18108 2017-10-04 06:45:27Z bignon $
 */
public class UnknownParameterException extends MathIllegalArgumentException {

    /** Serializable version Id. */
    private static final long serialVersionUID = 20120902L;

    /** Parameter name. */
    private final String name;

    /**
     * Construct an exception from the unknown parameter.
     * 
     * @param nameIn
     *        parameter name.
     */
    public UnknownParameterException(final String nameIn) {
        super(PatriusMessages.UNKNOWN_PARAMETER);
        this.name = nameIn;
    }

    /**
     * @return the name of the unknown parameter.
     */
    public String getName() {
        return this.name;
    }

}
